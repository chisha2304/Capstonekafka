﻿<!DOCTYPE HTML>
<!DOCTYPE html PUBLIC "" ""><HTML><HEAD><META content="IE=11.0000" 
http-equiv="X-UA-Compatible">

<META http-equiv="Content-Type" content="text/html; charset=utf-8">
<META name="GENERATOR" content="MSHTML 11.00.9600.19155"></HEAD>
<BODY>
<PRE>package kafka.consumerClient;

import database.Database;
import org.apache.kafka.clients.consumer.ConsumerRebalanceListener;
import org.apache.kafka.common.TopicPartition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;


public class MyConsumerRebalanceListener implements ConsumerRebalanceListener {

    private Logger logger = LoggerFactory.getLogger(MyConsumerRebalanceListener.class);
    private Database database;
    private Consumer consumer;


    public MyConsumerRebalanceListener(Consumer consumer, Database database) {
        this.consumer = consumer;
        this.database = database;
    }


    @Override
    public void onPartitionsRevoked(Collection&lt;TopicPartition&gt; partitions) {
        try {
            for (TopicPartition partition : partitions) {
                this.database.saveOffset(partition.topic(), partition.partition(), consumer.position(partition));
            }
        } catch (Exception e) {
            logger.error("Database Exception", e);
            this.consumer.shutdown();
        }
    }


    @Override
    public void onPartitionsAssigned(Collection&lt;TopicPartition&gt; partitions) {
        try {
            for (TopicPartition partition : partitions) {
                this.consumer.seek(partition, this.database.getOffset(partition.topic(), partition.partition()));
            }
        } catch (Exception e) {
            logger.error("Database Exception", e);
            this.consumer.shutdown();
        }
    }
}</PRE></BODY></HTML>
